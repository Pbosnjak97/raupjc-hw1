﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


    class Program
    {
        static void Main(string[] args)
        {
        IntegerList Lista = new IntegerList(10);
        Lista.Add(1);
        Lista.Add(2);
        Lista.Add(3);
        Lista.Add(4);
        Lista.Add(5);

        Lista.RemoveAt(0);
        Lista.Remove(5);
        Console.WriteLine(Lista.Count); 
        Console.WriteLine(Lista.Remove(100)); 
        Console.WriteLine(Lista.RemoveAt(2));
        Lista.Clear();
        Console.WriteLine(Lista.Count);
        Console.ReadLine();
    }
    }
