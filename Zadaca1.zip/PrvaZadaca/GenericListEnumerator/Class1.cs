﻿using System;
using System.Collections.Generic;

public class GenericListEnumerator<X> : IEnumerator<X>
{
    public GenericList<X> List;
    public X[] _internalStorage;

    int position = -1;

    public GenericListEnumerator(X[] list)
    {
        _internalStorage = list;
    }

    public bool MoveNext()
    {
        position++;
        return (position < _internalStorage.Length);
    }
    public void Reset()
    {
        position = -1;
    }

    object IEnumerator<X>.Current
    {
        get
        {
            return Current;
        }

    }

    public X Current
    {
        get
        {
            try
            {
                return _internalStorage[position];          
            }
            catch(IndexOutOfRangeException)
            {
                throw new InvalidOperationException();
            }
        }
    }
}

