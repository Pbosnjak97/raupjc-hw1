﻿using System;


class Program
{
    static void Main(string[] args)
    {
        GenericList<double> Lista = new GenericList<double>(10);
        Lista.Add(1.23);
        Lista.Add(2.56);
        Lista.Add(3);
        Lista.Add(4.555);
        Lista.Add(-5.098);

        Lista.RemoveAt(0);
        Lista.Remove(-5.098);
        Console.WriteLine(Lista.Count);
        Console.WriteLine(Lista.Remove(100));
        Console.WriteLine(Lista.RemoveAt(2));
        Lista.Clear();
        Console.WriteLine(Lista.Count);
        Console.ReadLine();

        
    }
}