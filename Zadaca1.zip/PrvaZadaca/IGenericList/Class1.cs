﻿using System;



public interface IGenericList<X>
{
    void Add(X item);
    bool Remove(X item);
    bool RemoveAt(int index);
    int IndexOf(X item);
    X GetElement(int index);
    int Count { get; }
    void Clear();
    bool Contains(X item);
}

public interface IComparable
{
    int CompareTo(object obj);
}


public class GenericList <X> : IGenericList<X>
{
    private X[] _internalStorage;
    private int pok;

    public GenericList() { _internalStorage = new X[4]; pok = 0; }
    public GenericList(int initialSize)
    {
        try
        {
            if (initialSize <= 0) throw new ArgumentException();
            _internalStorage = new X[initialSize];
            pok = 0;
        }
        catch (ArgumentException e)
        {
            Console.WriteLine("Negativan initialSize");
        }
    }

    public void Add(X item)
    {
        if (pok >= _internalStorage.Length)
        {
            X[] pom = new X[_internalStorage.Length + 1];
            for (int i = 0; i < _internalStorage.Length; i++) pom[i] = _internalStorage[i];
            _internalStorage = new X[_internalStorage.Length * 2 + 1];
            for (int i = 0; i < _internalStorage.Length; ++i) _internalStorage[i] = pom[i];
            _internalStorage[pok] = item;
            pok = pok + 1;
        }
        _internalStorage[pok] = item;
        pok = pok + 1;
    }

    public bool RemoveAt(int index)
    {
        if (index >= pok) throw new IndexOutOfRangeException();
        for (int i = index; i < _internalStorage.Length - 1; ++i)
            _internalStorage[i] = _internalStorage[i + 1];
        pok = pok - 1;
        return true;
    }

    public bool Remove(X item) 
    {
        for (int i = 0; i < _internalStorage.Length; ++i)
            if (((IComparable)_internalStorage[i]).CompareTo(item) == 0)
            {
                return RemoveAt(i);
            }
        return false;
    }

    public int IndexOf(X item)
    {
        for (int i = 0; i < _internalStorage.Length; ++i)
            if (((IComparable)_internalStorage[i]).CompareTo(item) == 0) return i;
        return -1;
    }

    public X GetElement(int index)
    {
        if (index < pok) return _internalStorage[index];
        throw new IndexOutOfRangeException();
    }

    public int Count
    {
        get => pok;
    }

    public void Clear()
    {
        pok = 0;
    }

    public bool Contains(X item)
    {
        for (int i = 0; i < _internalStorage.Length; ++i)
            if (((IComparable)_internalStorage[i]).CompareTo(item) == 0) return true;
        return false;
    }


}

