﻿using System;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


    public interface IIntergerList
    {
        void Add(int item);
        bool Remove(int item);
        bool RemoveAt(int index);
        int IndexOf(int item);
        int GetElement(int item);
        int Count { get; }
        void Clear();
        bool Contains(int item);
    }
    public class IntegerList : IIntergerList
    {
        private int[] _internalStorage;
        private int pok;

        public IntegerList() { _internalStorage = new int[4]; pok = 0; }
        public IntegerList(int initialSize)
        {
            try
            {
                if (initialSize <= 0) throw new ArgumentException();
                _internalStorage = new int[initialSize];
                pok = 0;
            }
            catch (ArgumentException e)
            {
                Console.WriteLine("Negativan initialSize");
            }
        }

        public void Add(int item)
        {
            if (pok >= _internalStorage.Length)
            {
                int[] pom = new int[_internalStorage.Length + 1];
                for (int i = 0; i < _internalStorage.Length; i++) pom[i] = _internalStorage[i];
                _internalStorage = new int[_internalStorage.Length * 2 + 1];
                for (int i = 0; i < _internalStorage.Length; ++i) _internalStorage[i] = pom[i];
                _internalStorage[pok] = item;
                pok = pok + 1;
            }
            _internalStorage[pok] = item;
            pok = pok + 1; 
        }

        public bool RemoveAt(int index)
        {
            if (index >= pok) throw new IndexOutOfRangeException();
            for (int i = index; i < _internalStorage.Length - 1; ++i)
                _internalStorage[i] = _internalStorage[i + 1];
            pok = pok - 1;
            return true;
        }

        public bool Remove(int item)
        {
            for (int i = 0; i < _internalStorage.Length; ++i)
                if (_internalStorage[i] == item)
                {
                    return RemoveAt(i);
                }
            return false;
        }

        public int IndexOf(int item)
        {
            for (int i = 0; i < _internalStorage.Length; ++i)
                if (_internalStorage[i] == item) return i;
            return -1;
        }

        public int GetElement(int index)
        {
            if (index < pok) return _internalStorage[index];
            throw new IndexOutOfRangeException();
        }

        public int Count
        {
            get => pok;
        }

        public void Clear()
        {
            pok = 0;
        }

        public bool Contains(int item)
        {
            for (int i = 0; i < _internalStorage.Length; ++i)
                if (_internalStorage[i] == item) return true;
            return false;
        }


    }


